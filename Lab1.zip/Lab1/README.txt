Lab1 is written in C++ code - lab1.cpp file

To Compile and run on Linux:
	Use: g++ -o lab1.out lab1.cpp // this will output a lab1.out file to run the shell

I mounted my local fold to docker to edit the c++ code using the code below: (please change directory if you are going to do the same way)
	docker run -it -v C:\Users\TN\Desktop\ComputerScience\OperatingSystem:/mnt/OperatingSystem ubuntu_cwu bin/bash // bind your local folder to docker container